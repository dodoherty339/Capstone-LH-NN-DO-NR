

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0366 */
/* at Mon Jul 18 10:16:45 2005
 */
/* Compiler settings for oledbdm.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__


#ifndef __oledbdm_h__
#define __oledbdm_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

/* interface __MIDL_itf_oledbdm_0000 */
/* [local] */ 

#define DBSOURCETYPE_DATASOURCE_DM (4)
#define OLEDB_DM_PROVIDER_STRING "OLE DB DM Provider"
#ifdef DBINITCONSTANTS
extern const OLEDBDECLSPEC GUID DMSCHEMA_MINING_SERVICES =
	{0x3add8a95,0xd8b9,0x11d2,{0x8d,0x2a,0x00,0xe0,0x29,0x15,0x4f,0xde}};
extern const OLEDBDECLSPEC GUID DMSCHEMA_MINING_SERVICE_PARAMETERS =
	{0x3add8a75,0xd8b9,0x11d2,{0x8d,0x2a,0x00,0xe0,0x29,0x15,0x4f,0xde}};
extern const OLEDBDECLSPEC GUID DMSCHEMA_MINING_MODEL_CONTENT =
	{0x3add8a76,0xd8b9,0x11d2,{0x8d,0x2a,0x00,0xe0,0x29,0x15,0x4f,0xde}};
extern const OLEDBDECLSPEC GUID DMSCHEMA_MINING_MODEL_XML =
	{0x4290b2d5,0xe9c,0x4aa7,{0x93,0x69,0x98,0xc9,0x5c,0xfd,0x9d,0x13}};
extern const OLEDBDECLSPEC GUID DMSCHEMA_MINING_MODELS =
	{0x3add8a77,0xd8b9,0x11d2,{0x8d,0x2a,0x00,0xe0,0x29,0x15,0x4f,0xde}};
extern const OLEDBDECLSPEC GUID DMSCHEMA_MINING_COLUMNS =
	{0x3add8a78,0xd8b9,0x11d2,{0x8d,0x2a,0x00,0xe0,0x29,0x15,0x4f,0xde}};
extern const OLEDBDECLSPEC GUID DMSCHEMA_MINING_FUNCTIONS =
	{0x3add8a79,0xd8b9,0x11d2,{0x8d,0x2a,0x00,0xe0,0x29,0x15,0x4f,0xde}};
extern const OLEDBDECLSPEC GUID DMSCHEMA_MINING_STRUCTURES =
	{0x883269f3,0x0cad,0x462f,{0xb6,0xf5,0xe8,0x8a,0x72,0x41,0x8c,0x4b}};
extern const OLEDBDECLSPEC GUID DMSCHEMA_MINING_STRUCTURE_COLUMNS =
	{0x9952e836,0xbfbf,0x4d1f,{0x85,0x35,0x9b,0x67,0xdb,0xd9,0xdd,0xfe}};
#else //!DBINITCONSTANTS
extern const GUID DMSCHEMA_MINING_SERVICES;
extern const GUID DMSCHEMA_MINING_SERVICE_PARAMETERS;
extern const GUID DMSCHEMA_MINING_MODEL_CONTENT;
extern const GUID DMSCHEMA_MINING_MODEL_XML;
extern const GUID DMSCHEMA_MINING_MODELS;
extern const GUID DMSCHEMA_MINING_COLUMNS;
extern const GUID DMSCHEMA_MINING_FUNCTIONS;
extern const GUID DMSCHEMA_MINING_STRUCTURES;
extern const GUID DMSCHEMA_MINING_STRUCTURE_COLUMNS;
#endif //DBINITCONSTANTS
// Fixing spec compliance issue in previous versions
#define  DMSCHEMA_MINING_MODEL_CONTENT_PMML DMSCHEMA_MINING_MODEL_XML
// Node types in MINING_MODEL_CONTENT schema rowset
const LONG DM_NODE_TYPE_MODEL					= 1;
const LONG DM_NODE_TYPE_CLASSIFICATION_TREE_ROOT	= 2;
const LONG DM_NODE_TYPE_TREE_INTERIOR			= 3;
const LONG DM_NODE_TYPE_TREE_DISTRIBUTION		= 4;
const LONG DM_NODE_TYPE_CLUSTER					= 5;
const LONG DM_NODE_TYPE_UNKNOWN					= 6;
const LONG DM_NODE_TYPE_ITEMSET					= 7;
const LONG DM_NODE_TYPE_ASSOCIATION_RULE			= 8;
const LONG DM_NODE_TYPE_NB_PREDICTABLE_ATTRIBUTE	= 9;
const LONG DM_NODE_TYPE_NB_INPUT_ATTRIBUTE		= 10;
const LONG DM_NODE_TYPE_NB_INPUT_ATTRIBUTE_STATE	= 11;
const LONG DM_NODE_TYPE_SEQUENCE					= 13;
const LONG DM_NODE_TYPE_TRANSITION				= 14;
const LONG DM_NODE_TYPE_TIME_SERIES				= 15;
const LONG DM_NODE_TYPE_TS_TREE					= 16;
const LONG DM_NODE_TYPE_NN_SUBNETWORK			= 17;
const LONG DM_NODE_TYPE_NN_INPUT_LAYER			= 18;
const LONG DM_NODE_TYPE_NN_HIDDEN_LAYER			= 19;
const LONG DM_NODE_TYPE_NN_OUTPUT_LAYER			= 20;
const LONG DM_NODE_TYPE_NN_INPUT_NODE			= 21;
const LONG DM_NODE_TYPE_NN_HIDDEN_NODE			= 22;
const LONG DM_NODE_TYPE_NN_OUTPUT_NODE			= 23;
const LONG DM_NODE_TYPE_NN_MARGINAL_STAT_NODE	= 24;
const LONG DM_NODE_TYPE_REGRESSION_TREE_ROOT		= 25;
const LONG DM_NODE_TYPE_NB_MARGINAL_STAT_NODE	= 26;
const LONG DM_NODE_TYPE_CUSTOM_BASE				= 1000;
//
// Tree Operators for MINING_MODEL_CONTENT schema rowset
#define     DMTREEOP_CHILDREN           0x01
#define     DMTREEOP_SIBLINGS           0x02
#define     DMTREEOP_PARENT             0x04
#define     DMTREEOP_SELF               0x08
#define     DMTREEOP_DESCENDANTS        0x10
#define     DMTREEOP_ANCESTORS          0x20

enum DM_MiningServiceTypeID
    {	DM_SERVICETYPE_CLASSIFICATION	= 0x1,
	DM_SERVICETYPE_CLUSTERING	= 0x2,
	DM_SERVICETYPE_ASSOCIATION	= 0x4,
	DM_SERVICETYPE_DENSITY_ESTIMATE	= 0x8,
	DM_SERVICETYPE_SEQUENCE	= 0x10
    } ;

enum DM_MiningServiceTrainingComplexity
    {	DM_TRAINING_COMPLEXITY_LOW	= 0,
	DM_TRAINING_COMPLEXITY_MEDIUM	= 1,
	DM_TRAINING_COMPLEXITY_HIGH	= 2
    } ;

enum DM_MiningServicePredictionComplexity
    {	DM_PREDICTION_COMPLEXITY_LOW	= 0,
	DM_PREDICTION_COMPLEXITY_MEDIUM	= 1,
	DM_PREDICTION_COMPLEXITY_HIGH	= 2
    } ;

enum DM_MiningServiceExpectedQuality
    {	DM_EXPECTED_QUALITY_LOW	= 0,
	DM_EXPECTED_QUALITY_MEDIUM	= 1,
	DM_EXPECTED_QUALITY_HIGH	= 2
    } ;

enum DM_MiningServiceScaling
    {	DM_SCALING_LOW	= 0,
	DM_SCALING_MEDIUM	= 1,
	DM_SCALING_HIGH	= 2
    } ;

enum DM_MiningServiceControl
    {	DM_CONTROL_NONE	= 0,
	DM_CONTROL_CANCEL	= 1,
	DM_CONTROL_SUSPENDRESUME	= 2,
	DM_CONTROL_SUSPENDWITHRESULT	= 3
    } ;

enum DM_MiningServiceParameterFlags
    {	DM_PARAMETER_TRAINING	= 0x1,
	DM_PARAMETER_PREDICTION	= 0x2
    } ;
#define	DMMVALUETYPE_AUTODETECT	( 0 )

#define	DMMVALUETYPE_MISSING	( 1 )

#define	DMMVALUETYPE_EXISTING	( 2 )

#define	DMMVALUETYPE_CONTINUOUS	( 3 )

#define	DMMVALUETYPE_DISCRETE	( 4 )

#define	DMMVALUETYPE_DISCRETIZED	( 5 )

#define	DMMVALUETYPE_BOOLEAN	( 6 )

#define	DMMVALUETYPE_COEFFICIENT	( 7 )

#define	DMMVALUETYPE_SCOREGAIN	( 8 )

#define	DMMVALUETYPE_STATISTICS	( 9 )

#define	DMMVALUETYPE_NODE_UNIQUE_NAME	( 10 )

#define	DMMVALUETYPE_INTERCEPT	( 11 )



extern RPC_IF_HANDLE __MIDL_itf_oledbdm_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_oledbdm_0000_v0_0_s_ifspec;

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


