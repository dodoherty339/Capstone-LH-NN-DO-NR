-- =============================================
-- Add another Sql Server as linked server
-- =============================================
sp_addlinkedserver N'<server_name, sysname, server1>', N'SQL Server'
GO

-- =============================================
-- List linked server
-- =============================================
sp_linkedservers
GO

