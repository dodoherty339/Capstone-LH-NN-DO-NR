-- =============================================
-- Drop Sql Server login
-- =============================================
sp_droplogin @loginame = N'<Sql_Server_login, sysname, test_login>'
GO

