-- ==========================
-- Unbind Default template
-- ==========================
-- This feature is marked for deprecation

EXEC sp_unbindefault N'<table_schema,,HumanResources>.<table_name,,Employee>.<column_name,,HireDate>'
GO