-- =============================================
-- Revoke dbaccess from User (User name in current Database, Windows User, or Sql Server login)
-- =============================================
sp_revokedbaccess @name_in_db = N'<db_user_name, sysname, test_user>'
GO

