-- =============================================
-- Add linked server login
-- =============================================
sp_addlinkedsrvlogin @rmtsrvname  = N'<server_name, sysname, server1>',
    		     @useself 	  = '<useself, varchar(8), TRUE>',
   		     @locallogin  = <locallogin, sysname, NULL>,
 		     @rmtuser     = <rmtuser, sysname, NULL>,
  		     @rmtpassword = <rmtpassword, sysname, NULL>
GO

