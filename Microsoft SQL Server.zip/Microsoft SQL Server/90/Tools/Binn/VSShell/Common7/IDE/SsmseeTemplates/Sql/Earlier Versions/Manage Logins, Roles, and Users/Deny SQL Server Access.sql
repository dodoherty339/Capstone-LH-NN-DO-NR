-- =============================================
-- Deny Sql Server access to Windows user or group
-- =============================================
sp_denylogin @loginame = N'<Windows_user_or_group, sysname, REDMOND\john>'
GO

